# coding: utf-8

from huaweicloudsdkcore.auth.credentials import BasicCredentials
from huaweicloudsdkcore.exceptions import exceptions
from model.vaderSentiment.vaderSentiment  import SentimentIntensityAnalyzer


def handler(event, context):
    print("event".center(100, '='))
    print(event)

    sentence = event["queryStringParameters"]["sentence"]
    analyzer = SentimentIntensityAnalyzer()
    vs = analyzer.polarity_scores(sentence.strip())
    print(sentence, vs)
    return {
        "statusCode": 200,
        "body": vs,
        "headers": {
            "Content-Type": "text/html",
        },
        "isBase64Encoded": False
    }
